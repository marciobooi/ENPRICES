function ctrs() {
    // const target = document.querySelector(".newMenu");  
    // const elementId = 'selectFuel'
    // const optionsArray = Object.keys(energyProducts)
    // const labelDescription = languageNameSpace.labels["MENU_FUEL"]
    // const activeElement = REF.product

    // const singleSelect = new Singleselect(elementId, optionsArray, labelDescription, activeElement, selectedValue => {       
    //     REF.product = selectedValue;
    // });

    // const singleSelectHTML = singleSelect.createSingleSelect();   
    // target.insertAdjacentHTML('beforeend', singleSelectHTML);

    // // $('#selectFuel').hover(
    // //     function() {
    // //       $(this).data('prevText', $(this).text());
    // //       $(this).html(`${languageNameSpace.labels['MENU_FUEL']}`);
    // //     },
    // //     function() {
    // //       const dropdownFuelList = $('#dropdown-fuel-list');
    // //       const prevText = dropdownFuelList.find('.dropdown-item.active span').text();
    // //       $(this).html(`${prevText}`);
    // //     }
    // //   );

}

